********************************************************************************
* TECHNICAL NOTE ON TAXABLE WAGES REPORTING IN TENNESSEE ADMINISTRATIVE DATA 
* Sara Spaziani, University of Warwick
* September 29, 2026
********************************************************************************

cap log close
log using "C:\Users\AGP2166\results\techincal_note.log", replace

**# 1) Import Employer-Level data from QCEW 
********************************************************************************
import delimited "D:\U\Brown University\Employer_Data_V1.txt", clear

su qtr_year 

count //12,045,233
local start=r(N)

* Drop unmergeable employers (no ID reported)
drop if bu_ui_employer_id==. 

* Drop inactive employers
drop if status=="2" 

* For simplicity, eliminate all duplicate employer-quarter-year observations
duplicates tag bu_ui_employer_id qtr_number qtr_year, g(tag)
keep if tag==0

count //
local end=r(N)

di `end'/`start'

* Rename for merging 
rename qtr_year year 
rename qtr_number quarter

* Keep only relevant variables 
keep bu_ui_employer_id year quarter total_wage tax_wage

* Save temporary file
tempfile temp 
save `temp'


**# 2) Import Employee-Level data from Wage Files
******************************************************************************** 
import delimited "D:\U\Brown University\new source\BU_UI_Employment.txt", clear 

rename wage_quarter quarter
rename wage_year year

collapse (sum) wage_amount, by(eid ui_employer_id year quarter)


** Generate Taxable wage base
   g       twb=7000
   replace twb=9000 if inrange(year, 2009, 2015)
   replace twb=8000 if inrange(year, 2016, 2017)
   label   var twb "Taxable Wage Base"

** Generate Quarterly taxable wages 

   * Worker appearance in the year ordered by quarter (1-4)
     bysort    ui_employer_id year eid (quarter) : gen nw_y=_n 
	 label var nw_y "Worker Appearence in the Year"
	 su nw_y
	 
   * 1st appearance:  
	 g       tool=wage_amount if wage_amount<=twb & nw==1
     replace tool=twb if wage_amount>twb          & nw==1
     egen    tot1=total(tool), by(ui_employer_id year eid) // cumulative 

   * 2nd appearance
     replace tool=wage_amount if nw==2 & tot1+wage_amount<=twb
     replace tool=twb-tot1    if nw==2 & tot1+wage_amount>twb & tot1<twb
     replace tool=0           if nw==2 & tot1>=twb
     egen    tot2=total(tool), by(ui_employer_id year eid) //cumulative
	 
   * 3rd appearance 
     replace tool=wage_amount if nw==3 & tot2+wage_amount<=twb
     replace tool=twb-tot2    if nw==3 & tot2+wage_amount>twb & tot2<twb
     replace tool=0           if nw==3 & tot2>=twb
     egen    tot3=total(tool), by(ui_employer_id year eid)
	 
   * 4th appearance
     replace tool=wage_amount if nw==4 & tot3+wage_amount<=twb
     replace tool=twb-tot3    if nw==4 & tot3+wage_amount>twb & tot3<twb
     replace tool=0           if nw==4 & tot3>=twb //cumulative
	 
   rename tool tax_wage_w 
   label var   tax_wage "Worker's quarterly taxable wages"


   rename ui_employer_id bu_ui_employer_id
   
* Take the sum of all the wages paid by an employer in a year-quarter
collapse (sum) wage_amount tax_wage_w, by(bu_ui_employer_id year quarter)
count 


**# 3) Merge Employer and Employee-Level Data 
********************************************************************************

merge 1:1 bu_ui_employer_id year quarter using `temp'

tab _merge
keep if _merge==3 

save "C:\Users\AGP2166\data\technical_note_sample.dta", replace

gen yq=yq(year, quarter)


* % observations with taxable = total wages from the employer data in 2004-2015
count if inrange(year, 2004, 2015)
local tot=r(N)
count if inrange(year, 2004, 2015) & tax_wage==total_wage 
local equal=r(N)
local share= round(( `equal'/ `tot')*100, 0.001)
di " `share'% of the employer-quarter observations have total wages equal to taxable wages"

* Correlations 
corr tax_wage tax_wage_w if year>=2016 
corr tax_wage tax_wage_w if year>=2016 & quarter==1
corr tax_wage tax_wage_w if year>=2016 & quarter==2
corr tax_wage tax_wage_w if year>=2016 & quarter==3
corr tax_wage tax_wage_w if year>=2016 & quarter==4
corr tax_wage tax_wage_w if year>=2016 & year<=2021

* Differences
su tax_wage if year>=2016
g diff=abs(tax_wage_w- tax_wage)
su diff if year>=2016, d


**#4) Take average across employers of total and taxable wages over time between
*    Employer and Employee Level Data 
********************************************************************************
collapse total_wage tax_wage wage_amount tax_wage_w, by(yq)
label var total_wage "Average of Total Wages (Employer Data)"
label var wage_amount "Average of Total Wages (Employee Data)"
label var tax_wage "Average of Taxable Wages (Employer Data)"
label var tax_wage_w "Average of Taxable Wages (Employee Data)"

replace total_wage=total_wage/1000
replace tax_wage=tax_wage/1000
replace wage_amount=wage_amount/1000
replace tax_wage_w=tax_wage_w/1000



**# 5) Figure 1: Average Employer Total and Taxable Wages in The Employer Data 
********************************************************************************

#delimit; 
twoway (line total_wage yq, color(navy) lw(medthick)) 
       (line tax_wage yq, color(red) lp(dash) lw(medthick)),  
	   xlabel(168 "2002" 172 "2003" 176 "2004" 180 "2005" 184 "2006" 188 "2007" 192 "2008" 196 "2009" 200 "2010" 204 "2011" 208 "2012" 212 "2013" 216 "2014" 220 "2015" 224 "2016" 228 "2017" 232 "2018" 236 "2019" 240 "2020" 244 "2021" 248 "2022"
	   252 "2023" 256 "2024", angle(90))
	   xtitle("") 
	   legend(title(Average of Quarterly Wages, size(medsmall)) order(1 "Total (Employer-Level Data)" 2 "Taxable (Employer-Level Data)") ring(0) pos(11) size(medsmall))
	   ylabel(0(50)550) 
	   ytitle("Thousand $")
	   ;
	   #delimit cr
graph export "C:\Users\AGP2166\results\techincalnote_tot_tax_wage.pdf", replace


**# 6) Figure 2: Average Employer Total Wages in the Employer and Employee Data
********************************************************************************

#delimit; 
twoway (line total_wage yq, color(navy) lw(medthick))
       (line wage_amount yq, color(red) lp(dash) lw(medthick)), 
	   legend(title(Average of Total Wages in, size(medsmall)) order(1 "Employer Data" 2 "Employee Data") cols(1) 
	   size(medsmall) ring(0) pos(11))
	   ytitle("Thousand $") 
	   xlab(168 "2002" 172 "2003" 176 "2004" 180 "2005" 184 "2006" 188 "2007" 192 "2008" 196 "2009" 200 "2010" 204 "2011" 208 "2012" 212 "2013" 216 "2014" 220 "2015" 224 "2016" 228 "2017" 232 "2018" 236 "2019" 240 "2020" 244 "2021" 248 "2022" 252 "2023" 256 "2024", angle(90)) 
	   xtitle("")
	   ylab(150(50)500)
	   	 ;
	   #delimit cr
graph export "C:\Users\AGP2166\results\technicalnote_tot_wage.pdf", replace


**# 7) Figure 3: Average Employer Taxable Wages in the Employer and Employee Data 
********************************************************************************

#delimit;
twoway (line tax_wage yq, color(navy) lw(medthick))
       (line tax_wage_w yq, color(red) lw(medthick) lp(dash)), 
	   legend(title(Average of Taxable Wages in, size(medsmall))
	   order(1 "Employer Data" 2 "Employee Data") cols(1) ring(0) pos(2) size(medsmall)) 
	   ytitle("Thousand $") 
	   xlab(168 "2002" 172 "2003" 176 "2004" 180 "2005" 184 "2006" 188 "2007" 192 "2008" 196 "2009" 200 "2010" 204 "2011" 208 "2012" 212 "2013" 216 "2014" 220 "2015" 224 "2016" 228 "2017" 232 "2018" 236 "2019" 240 "2020" 244 "2021" 248 "2022" 252 "2023" 256 "2024" 260 " ", angle(90)) 
	   xtitle("")
	   ylab(0(50)350)
	   	 ;
	   #delimit cr
graph export "C:\Users\AGP2166\results\technicalnote_tax_wage.pdf", replace


log close
